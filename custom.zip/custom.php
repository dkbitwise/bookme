<?php
function add_faculty_role_and_capability() {
    /* execute only one time */
    //delete_option('faculty_role_and_capability');

    if ( get_option( 'faculty_role_and_capability' ) !=true ) {

        /* create faculty role */
        add_role('faculty', __(
            'Faculty'),
            array(
                'read'            => true, // Allows a user to read
                'create_posts'    => true, // Allows user to create new posts
                'edit_posts'      => false, // Allows user to edit their own posts,
            )
        );

        /* Add faculty capability */
        $role = get_role( 'faculty' );
        $role->add_cap('manage_bookme_menu');
        $role->add_cap('manage_bookme_booking_list');
        $role->add_cap('manage_bookme_calender_list');

        /* Add admin capability */
        $role = get_role( 'administrator' );
        $role->add_cap('manage_bookme_menu');
        $role->add_cap('manage_bookme_service_list');
        $role->add_cap('manage_bookme_service_add');
        $role->add_cap('manage_bookme_staff_list');
        $role->add_cap('manage_bookme_booking_list');
        $role->add_cap('manage_bookme_setting');
        $role->add_cap('manage_bookme_customer_list');
        $role->add_cap('manage_bookme_calender_list');

        update_option( 'faculty_role_and_capability', true );
    }

}
add_action( 'admin_init', 'add_faculty_role_and_capability' );

function get_month_date($date){
    $query_date = $date;

    $start_day=date('Y-m-01', strtotime($query_date));
    $end_day=date('Y-m-t', strtotime($query_date));

    $dateArr = getDateForSpecificDayBetweenDates($start_day,$end_day,date('w', strtotime($query_date)));
    return $dateArr;
}


function getDateForSpecificDayBetweenDates($startDate, $endDate, $weekdayNumber){
    $startDate = strtotime($startDate);
    $endDate = strtotime($endDate);

    $dateArr = array();

    do {
        if(date("w", $startDate) != $weekdayNumber) {
            $startDate += (24 * 3600); // add 1 day
        }
    }
    while(date("w", $startDate) != $weekdayNumber);

    while($startDate <= $endDate) {
        if ( date('Y-m-d', $startDate) > date('Y-m-d') ) {
            $dateArr[] = date('Y-m-d', $startDate);
        }
        $startDate += (7 * 24 * 3600); // add 7 days
    }
    return($dateArr);
}

add_action('woocommerce_order_details_before_order_table','sample_text');
function sample_text($order){
   echo "<a href='".site_url().booking_list_page."/'><button>View Bookings</button></a>";
}
